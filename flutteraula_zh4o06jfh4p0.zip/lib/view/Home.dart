import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text("Lista de Compras"),
          centerTitle: true,
          backgroundColor: Colors.teal
      ),
      body: Column(
        children: [
          Expanded(
            child: Container(),
          ),
          Container(
            height: 100,
            margin: EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    cursorColor: Colors.teal,
                    decoration: InputDecoration(
                      labelText: 'Novo Item'
                    ),
                  ),
                ),
                FloatingActionButton(
                  onPressed: () {},
                  backgroundColor: Colors.teal,
                  child: Icon(Icons.add),
                )
              ],
            )
          )
        ],
      )
    );
  }
}
